

for i in $@ ; do echo $i ; tail -n 3 $i;  done

