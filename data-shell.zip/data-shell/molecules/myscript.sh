for file in *.pdb; do cat $file | head -n 3; done
